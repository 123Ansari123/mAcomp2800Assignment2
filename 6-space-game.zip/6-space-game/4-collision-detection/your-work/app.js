// @ts-nocheck  // This turns off TypeScript checking

class EventEmitter {
	constructor() {
		this.listeners = {};
	}

	on(message, listener) {
		if (!this.listeners[message]) {
			this.listeners[message] = [];
		}
		this.listeners[message].push(listener);
	}

	emit(message, payload = null) {
		if (this.listeners[message]) {
			this.listeners[message].forEach((l) => l(message, payload));
		}
	}
}

class GameObject {
	constructor(x, y) {
		this.x = x;
		this.y = y;
		this.dead = false;
		this.type = '';
		this.width = 0;
		this.height = 0;
		this.img = undefined;
	}

	draw(ctx) {
		if (this.img && !this.dead) {
			ctx.drawImage(this.img, this.x, this.y, this.width, this.height);
		}
	}
}

class Hero extends GameObject {
	constructor(x, y) {
		super(x, y);
		this.width = 99;
		this.height = 75;
		this.type = 'Hero';
		this.speed = { x: 0, y: 0 };
	}
}

class Enemy extends GameObject {
	constructor(x, y) {
		super(x, y);
		this.width = 98;
		this.height = 50;
		this.type = 'Enemy';
		
		// Store canvas reference locally
		const canvas = document.getElementById('canvas');
		
		let id = setInterval(() => {
			if (this.y < canvas.height - this.height) {
				this.y += 5;
			} else {
				console.log('Stopped at', this.y);
				clearInterval(id);
			}
		}, 300);
	}
}

class Laser extends GameObject {
	constructor(x, y) {
		super(x, y);
		this.width = 9;
		this.height = 33;
		this.type = 'Laser';
		
		let id = setInterval(() => {
			if (this.y > 0) {
				this.y -= 15;
			} else {
				this.dead = true;
				clearInterval(id);
			}
		}, 100);
	}
}

function loadTexture(path) {
	return new Promise((resolve) => {
		const img = new Image();
		img.src = path;
		img.onload = () => {
			resolve(img);
		};
	});
}

const Messages = {
	KEY_EVENT_UP: 'KEY_EVENT_UP',
	KEY_EVENT_DOWN: 'KEY_EVENT_DOWN',
	KEY_EVENT_LEFT: 'KEY_EVENT_LEFT',
	KEY_EVENT_RIGHT: 'KEY_EVENT_RIGHT',
	KEY_EVENT_SPACE: 'KEY_EVENT_SPACE',
	COLLISION_ENEMY_LASER: 'COLLISION_ENEMY_LASER',
	COLLISION_ENEMY_HERO: 'COLLISION_ENEMY_HERO'
};

// Game variables
let heroImg, enemyImg, laserImg, canvas, ctx, gameObjects = [], hero;
const eventEmitter = new EventEmitter();

// Keyboard events
window.addEventListener('keydown', (e) => {
	// Prevent default for game controls
	if ([37, 38, 39, 40, 32].includes(e.keyCode)) {
		e.preventDefault();
	}
});

window.addEventListener('keyup', (evt) => {
	if (evt.key === 'ArrowUp') {
		eventEmitter.emit(Messages.KEY_EVENT_UP);
	} else if (evt.key === 'ArrowDown') {
		eventEmitter.emit(Messages.KEY_EVENT_DOWN);
	} else if (evt.key === 'ArrowLeft') {
		eventEmitter.emit(Messages.KEY_EVENT_LEFT);
	} else if (evt.key === 'ArrowRight') {
		eventEmitter.emit(Messages.KEY_EVENT_RIGHT);
	} else if (evt.key === ' ') {
		eventEmitter.emit(Messages.KEY_EVENT_SPACE);
	}
});

function rectCollide(r1, r2) {
	return !(r2.x > r1.x + r1.width || 
			 r2.x + r2.width < r1.x || 
			 r2.y > r1.y + r1.height ||
			 r2.y + r2.height < r1.y);
}

function checkCollisions() {
	for (let i = 0; i < gameObjects.length; i++) {
		for (let j = i + 1; j < gameObjects.length; j++) {
			const obj1 = gameObjects[i];
			const obj2 = gameObjects[j];
			
			if (obj1.dead || obj2.dead) continue;
			
			if (rectCollide(obj1, obj2)) {
				// Laser hits Enemy
				if (obj1.type === 'Laser' && obj2.type === 'Enemy') {
					obj1.dead = true;
					obj2.dead = true;
					eventEmitter.emit(Messages.COLLISION_ENEMY_LASER, { enemy: obj2 });
				}
				else if (obj2.type === 'Laser' && obj1.type === 'Enemy') {
					obj2.dead = true;
					obj1.dead = true;
					eventEmitter.emit(Messages.COLLISION_ENEMY_LASER, { enemy: obj1 });
				}
				
				// Enemy hits Hero
				if (obj1.type === 'Enemy' && obj2.type === 'Hero') {
					eventEmitter.emit(Messages.COLLISION_ENEMY_HERO, { enemy: obj1, hero: obj2 });
				}
				else if (obj2.type === 'Enemy' && obj1.type === 'Hero') {
					eventEmitter.emit(Messages.COLLISION_ENEMY_HERO, { enemy: obj2, hero: obj1 });
				}
			}
		}
	}
}

function removeDeadObjects() {
	gameObjects = gameObjects.filter(obj => !obj.dead);
}

function createEnemies() {
	const MONSTER_TOTAL = 5;
	const MONSTER_WIDTH = MONSTER_TOTAL * 98;
	const START_X = (canvas.width - MONSTER_WIDTH) / 2;
	const STOP_X = START_X + MONSTER_WIDTH;

	for (let x = START_X; x < STOP_X; x += 98) {
		for (let y = 0; y < 50 * 5; y += 50) {
			const enemy = new Enemy(x, y);
			enemy.img = enemyImg;
			gameObjects.push(enemy);
		}
	}
}

function createHero() {
	hero = new Hero(
		canvas.width / 2 - 45, 
		canvas.height - canvas.height / 4
	);
	hero.img = heroImg;
	gameObjects.push(hero);
}

function drawGameObjects(ctx) {
	gameObjects.forEach((go) => go.draw(ctx));
}

function initGame() {
	gameObjects = [];
	createEnemies();
	createHero();

	// Hero movement
	eventEmitter.on(Messages.KEY_EVENT_UP, () => {
		if (hero.y > 0) hero.y -= 5;
	});

	eventEmitter.on(Messages.KEY_EVENT_DOWN, () => {
		if (hero.y < canvas.height - hero.height) hero.y += 5;
	});

	eventEmitter.on(Messages.KEY_EVENT_LEFT, () => {
		if (hero.x > 0) hero.x -= 5;
	});

	eventEmitter.on(Messages.KEY_EVENT_RIGHT, () => {
		if (hero.x < canvas.width - hero.width) hero.x += 5;
	});
	
	// Shooting
	eventEmitter.on(Messages.KEY_EVENT_SPACE, () => {
		const laser = new Laser(hero.x + 45, hero.y - 30);
		laser.img = laserImg;
		gameObjects.push(laser);
	});
	
	// Collision events
	eventEmitter.on(Messages.COLLISION_ENEMY_LASER, () => {
		console.log('Enemy destroyed!');
	});
	
	eventEmitter.on(Messages.COLLISION_ENEMY_HERO, () => {
		console.log('GAME OVER! Hero hit by enemy');
	});
}

window.onload = async () => {
	canvas = document.getElementById('canvas');
	ctx = canvas.getContext('2d');
	
	// Set canvas size
	canvas.width = 800;
	canvas.height = 600;
	
	heroImg = await loadTexture('assets/player.png');
	enemyImg = await loadTexture('assets/enemyShip.png');
	laserImg = await loadTexture('assets/laserRed.png');

	initGame();
	
	setInterval(() => {
		ctx.clearRect(0, 0, canvas.width, canvas.height);
		ctx.fillStyle = 'black';
		ctx.fillRect(0, 0, canvas.width, canvas.height);
		
		checkCollisions();
		removeDeadObjects();
		drawGameObjects(ctx);
	}, 100);
};