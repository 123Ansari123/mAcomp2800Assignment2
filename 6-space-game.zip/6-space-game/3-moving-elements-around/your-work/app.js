/**
 * SPACE INVADERS GAME - LESSON 3
 * This file handles the core game mechanics including:
 * - Loading game assets (images)
 * - Creating enemy formations
 * - Drawing the initial game screen
 */

/**
 * Loads an image texture from the specified path
 * Uses Promise to ensure image is fully loaded before rendering
 * 
 * @param {string} path - The file path to the image
 * @returns {Promise<Image>} Promise that resolves with the loaded image
 */
function loadTexture(path) {
  return new Promise((resolve) => {
    const img = new Image();
    img.src = path;
    img.onload = () => {
      resolve(img); // Image loaded successfully
    };
    // Note: Error handling could be added here for production
  });
}

/**
 * Creates and positions enemy ships on the canvas
 * Arranges enemies in a grid pattern at the top of the screen
 * 
 * @param {CanvasRenderingContext2D} ctx - The canvas rendering context
 * @param {HTMLCanvasElement} canvas - The game canvas element
 * @param {Image} enemyImg - The enemy ship image to draw
 */
function createEnemies(ctx, canvas, enemyImg) {
  // Configuration constants for enemy formation
  const MONSTER_TOTAL = 5;              // Number of enemies per row
  const MONSTER_WIDTH = MONSTER_TOTAL * 98; // Total width of enemy formation
  const START_X = (canvas.width - MONSTER_WIDTH) / 2; // Center the formation
  const STOP_X = START_X + MONSTER_WIDTH; // Rightmost enemy position

  // Draw enemies in a grid: 5 columns x 5 rows
  for (let x = START_X; x < STOP_X; x += 98) {     // Loop through columns
    for (let y = 0; y < 50 * 5; y += 50) {         // Loop through rows
      ctx.drawImage(enemyImg, x, y);                // Draw individual enemy
    }
  }
}

/**
 * Main game initialization function
 * Runs when the page loads and sets up the game environment
 */
window.onload = async () => {
  /*** CANVAS SETUP ***/
  canvas = document.getElementById("canvas");        // Get canvas element from HTML
  ctx = canvas.getContext("2d");                     // Get 2D drawing context
  
  /*** ASSET LOADING ***/
  // Load all game images asynchronously
  const heroImg = await loadTexture("assets/player.png");      // Player spaceship
  const enemyImg = await loadTexture("assets/enemyShip.png");  // Enemy ships

  /*** INITIAL DRAWING ***/
  // Clear canvas with black background
  ctx.fillStyle = "black";                           // Set background color
  ctx.fillRect(0, 0, canvas.width, canvas.height);   // Fill entire canvas
  
  // Draw player ship at bottom center of screen
  ctx.drawImage(
    heroImg,
    canvas.width / 2 - 45,                           // X position (centered)
    canvas.height - canvas.height / 4                 // Y position (near bottom)
  );
  
  // Draw all enemy ships in formation
  createEnemies(ctx, canvas, enemyImg);
  
  /**
   * TODO: Future enhancements for Lesson 4+
   * - Add game loop for continuous updates
   * - Implement keyboard controls for player movement
   * - Add shooting mechanics
   * - Implement collision detection
   */
};