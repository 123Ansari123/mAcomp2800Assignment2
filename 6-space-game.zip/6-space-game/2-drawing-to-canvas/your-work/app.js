function loadTexture(path) {
  return new Promise((resolve) => {
    const img = new Image()
    img.src = path
    img.onload = () => {
      resolve(img)
    }
  })
}

function createEnemies(ctx, canvas, enemyImg) {
  // TODO draw enemies - Let's fix this!
  const enemyWidth = 30;
  const enemyHeight = 30;
  const rows = 3;
  const cols = 8;
  
  for (let row = 0; row < rows; row++) {
    for (let col = 0; col < cols; col++) {
      const x = 50 + col * 60;  // Space enemies horizontally
      const y = 50 + row * 40;  // Space enemies vertically
      ctx.drawImage(enemyImg, x, y, enemyWidth, enemyHeight);
    }
  }
}

window.onload = async () => {
  canvas = document.getElementById('canvas')
  ctx = canvas.getContext('2d')
  
  // TODO load textures - Let's fix this!
  const playerImg = await loadTexture('assets/player.png');
  const enemyImg = await loadTexture('assets/enemyShip.png');
  
  // TODO draw black background - Let's fix this!
  ctx.fillStyle = 'black';
  ctx.fillRect(0, 0, canvas.width, canvas.height);
  
  // TODO draw hero - Let's fix this!
  const playerX = canvas.width / 2 - 15;  // Center the player
  const playerY = canvas.height - 50;     // Near bottom
  ctx.drawImage(playerImg, playerX, playerY, 30, 30);
  
  // TODO uncomment the next line when you add enemies to screen
  createEnemies(ctx, canvas, enemyImg);
}